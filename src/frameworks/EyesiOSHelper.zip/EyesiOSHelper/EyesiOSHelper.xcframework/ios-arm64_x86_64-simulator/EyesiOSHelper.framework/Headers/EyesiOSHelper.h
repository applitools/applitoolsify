// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import <Foundation/Foundation.h>

//! Project version number for EyesiOSHelper.
FOUNDATION_EXPORT double EyesiOSHelperVersionNumber;

//! Project version string for EyesiOSHelper.
FOUNDATION_EXPORT const unsigned char EyesiOSHelperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EyesiOSHelper/PublicHeader.h>

@interface EyesiOSHelper : NSObject

+ (instancetype)sharedInstance;
- (void)initialize;

@end
